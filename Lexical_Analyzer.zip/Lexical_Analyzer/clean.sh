#! /bin/bash

rm dist/als
rm src/alpha_lexical_scanner.c