|*************************|
| AM4361  AM4398   AM4406 |
|*************************|

# First Phase, Lexical Analysis

To build the Lexical Analyzer execute the build script.sh `./build.sh`
To run the Lexical Analyzer execute the al application inside dist folder `./dist/al`
To clean up the executable and the generated code execute the clean script.sh `./clean.sh`

The program was ran and tested at the Avocado machine.