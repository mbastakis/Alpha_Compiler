# Tested Cases
- 

# Tested Grammar Rules
- 
- 

# Insert a Symbol
- Prepei na min einai null
- Prepei sto scope na min uparxei allo symbol me to idio name
    -
    -
- 